//
//  MyCoreDataController.m
//  MyCoreDataProject
//
//  Created by Toru Inoue on 11/04/14.
//  Copyright 2011 KISSAKI. All rights reserved.
//

#import "MyCoreDataController.h"
#import "MyEntity01.h"

@implementation MyCoreDataController


- (void) create {
	NSManagedObjectContext * currentContext = [self myNSManagedObjectContext];
	MyEntity01 * newEntity = (MyEntity01 * )[NSEntityDescription insertNewObjectForEntityForName:@"MyEntity01" inManagedObjectContext:currentContext];
	
	[newEntity setEventName:@"アンパンマン新しい顔よ！"];
	[newEntity setEventDate:[NSDate date]];
	
	
	NSError * saveError = nil;
	if (![currentContext save:&saveError]) {
		if (saveError) {
			NSLog(@"save_error_%@", saveError);
		}
	}
}


- (void) load {
	NSManagedObjectContext * currentContext = [self myNSManagedObjectContext];
	
	NSFetchRequest * request = [[[NSFetchRequest alloc] init] autorelease];
	
	NSEntityDescription * entity = [NSEntityDescription entityForName:@"MyEntity01" inManagedObjectContext:currentContext];
	[request setEntity:entity];
	
	
	NSError * loadError = nil;
	NSMutableArray * mutableFetchResults = [[[currentContext executeFetchRequest:request error:&loadError] mutableCopy] autorelease];
	
	if (mutableFetchResults == nil) {
		NSLog(@"Unnatural result?_%@", loadError);
	}
	
	for (MyEntity01 * currentEntity in mutableFetchResults) {
		NSLog(@"currentEntity_%@",[currentEntity EventName]);
		[currentEntity setEventName:@"元気百倍って凄くね"];
	}
	
	[self create];
}

- (NSMutableArray * ) loadAsArrayOfMyEntity01 {
	NSManagedObjectContext * currentContext = [self myNSManagedObjectContext];
	
	NSFetchRequest * request = [[[NSFetchRequest alloc] init] autorelease];
	
	NSEntityDescription * entity = [NSEntityDescription entityForName:@"MyEntity01" inManagedObjectContext:currentContext];
	[request setEntity:entity];
	
	
	NSError * loadError = nil;
	NSMutableArray * mutableFetchResults = [[[currentContext executeFetchRequest:request error:&loadError] mutableCopy] autorelease];
	
	return mutableFetchResults;
}

- (void) deleteFirstObject {
	NSManagedObjectContext * currentContext = [self myNSManagedObjectContext];
	[currentContext deleteObject:[[self loadAsArrayOfMyEntity01] objectAtIndex:0]];
	
	NSError * saveError = nil;
	if (![currentContext save:&saveError]) {
		if (saveError) {
			NSLog(@"save_error_%@", saveError);
		}
	}
	
	for (MyEntity01 * currentEntity in [self loadAsArrayOfMyEntity01]) {
		NSLog(@"currentEntity_%@",[currentEntity EventName]);
	}
}

- (void) deleteAllObjects {
	NSManagedObjectContext * currentContext = [self myNSManagedObjectContext];
	
	for (MyEntity01 * currentEntity in [self loadAsArrayOfMyEntity01]) {
		[currentContext deleteObject:currentEntity];
	}
	
	NSError * saveError = nil;
	if (![currentContext save:&saveError]) {
		if (saveError) {
			NSLog(@"save_error_%@", saveError);
		}
	}
}


- (void) show {
	NSManagedObjectContext * currentContext = [self myNSManagedObjectContext];
	
	NSFetchRequest * request = [[[NSFetchRequest alloc] init] autorelease];
	
	NSEntityDescription * entity = [NSEntityDescription entityForName:@"MyEntity01" inManagedObjectContext:currentContext];
	[request setEntity:entity];
	
	
	NSError * loadError = nil;
	NSMutableArray * mutableFetchResults = [[[currentContext executeFetchRequest:request error:&loadError] mutableCopy] autorelease];
	
	if (mutableFetchResults == nil) {
		NSLog(@"Unnatural result?_%@", loadError);
	}
	
	for (MyEntity01 * currentEntity in mutableFetchResults) {
		NSLog(@"show	%@	%@",[currentEntity EventName], [currentEntity EventDate]);
	}
	
	if ([mutableFetchResults count] == 0) {
		NSLog(@"no data");
	}
}


- (NSPersistentStoreCoordinator * ) myNSPersistentStoreCoordinator {
	
    if (myNSPersistentStoreCoordinator != nil) {
        return myNSPersistentStoreCoordinator;
    }
	
	
    NSURL * storeUrl = [NSURL fileURLWithPath:
						[
						 [self applicationDocumentsDirectory] stringByAppendingPathComponent:
						 [NSString stringWithFormat:@"MySaveData.sqlite"]
						 ]
						];
	
	NSError * storeSettingError = nil;
	
    myNSPersistentStoreCoordinator = [[NSPersistentStoreCoordinator alloc] initWithManagedObjectModel:[self myNSManagedObjectModel]];
	
	if (![myNSPersistentStoreCoordinator addPersistentStoreWithType:NSSQLiteStoreType 
													  configuration:nil 
																URL:storeUrl 
															options:nil 
															  error:&storeSettingError]) {
		if (storeSettingError) {
			NSLog(@"storeSettingError_%@", storeSettingError);
		}
        NSAssert(FALSE, @"wrong pass");
    }
    return myNSPersistentStoreCoordinator;
}


- (NSString * ) applicationDocumentsDirectory {
	return [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
}







- (NSManagedObjectModel * ) myNSManagedObjectModel {
	
	if (myNSManagedObjectModel != nil) {
		return myNSManagedObjectModel;
    }
	
	myNSManagedObjectModel = [NSManagedObjectModel mergedModelFromBundles:nil];
	
	return myNSManagedObjectModel;
}



- (NSManagedObjectContext * ) myNSManagedObjectContext {
	
	if (myNSManagedObjectContext != nil) {
        return myNSManagedObjectContext;
    }
	
    NSPersistentStoreCoordinator * coordinator = [self myNSPersistentStoreCoordinator];
    if (coordinator != nil) {
        myNSManagedObjectContext = [NSManagedObjectContext new];
        [myNSManagedObjectContext setPersistentStoreCoordinator:coordinator];
    }
	
    return myNSManagedObjectContext;
}







@end
