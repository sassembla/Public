// 
//  MyEntity01.m
//  MyCoreDataProject
//
//  Created by Toru Inoue on 11/04/15.
//  Copyright 2011 KISSAKI. All rights reserved.
//

#import "MyEntity01.h"


@implementation MyEntity01 

@dynamic EventName;
@dynamic EventDate;
@dynamic EventPlace;

@end
