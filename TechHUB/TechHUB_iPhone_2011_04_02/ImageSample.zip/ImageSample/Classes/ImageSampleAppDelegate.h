//
//  ImageSampleAppDelegate.h
//  ImageSample
//
//  Created by Toru Inoue on 11/03/30.
//  Copyright 2011 KISSAKI. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ImageSampleViewController.h"


@interface ImageSampleAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
	ImageSampleViewController * viewCont;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end

