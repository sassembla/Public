//
//  ImageSampleViewController.h
//  ImageSample
//
//  Created by Toru Inoue on 11/03/30.
//  Copyright 2011 KISSAKI. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface ImageSampleViewController : UIViewController {
	IBOutlet UIImageView * m_imageView;
}

- (void) timeCome;

@end
 