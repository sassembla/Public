//
//  TableSampleAppDelegate.h
//  TableSample
//
//  Created by Toru Inoue on 11/04/01.
//  Copyright 2011 KISSAKI. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TableSampleAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end

