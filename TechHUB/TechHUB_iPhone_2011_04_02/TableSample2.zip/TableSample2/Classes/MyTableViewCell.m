//
//  MyTableViewCell.m
//  TableSample2
//
//  Created by Toru Inoue on 11/04/02.
//  Copyright 2011 KISSAKI. All rights reserved.
//

#import "MyTableViewCell.h"


@implementation MyTableViewCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code.
    }
    return self;
}


- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state.
}

- (void) animation {
	NSBundle * currentBundle = [[NSBundle mainBundle] autorelease];
	UIImage * toLeftImage = [[UIImage alloc]initWithContentsOfFile:[currentBundle pathForResource:@"a8b7e97d" ofType:@"jpg"]];
	UIImage * toRightImage = [[UIImage alloc]initWithContentsOfFile:[currentBundle pathForResource:@"25270571" ofType:@"jpg"]];
	
	
	[UIView beginAnimations:@"高速めくりあげ" context:nil];
	[UIView setAnimationDuration:0.5f];
	[m_left setImage:toLeftImage];
	[m_right setImage:toRightImage];
	[UIView setAnimationTransition:UIViewAnimationTransitionFlipFromLeft forView:self cache:FALSE];
	
	[UIView commitAnimations];
	
}

- (void)dealloc {
    [super dealloc];
}


@end
