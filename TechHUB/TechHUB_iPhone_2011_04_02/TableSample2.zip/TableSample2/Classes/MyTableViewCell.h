//
//  MyTableViewCell.h
//  TableSample2
//
//  Created by Toru Inoue on 11/04/02.
//  Copyright 2011 KISSAKI. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface MyTableViewCell : UITableViewCell {
	IBOutlet UIImageView * m_left;
	IBOutlet UIImageView * m_right;
}

- (void) animation;

@end
