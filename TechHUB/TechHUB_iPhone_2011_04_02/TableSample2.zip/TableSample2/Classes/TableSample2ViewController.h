//
//  TableSample2ViewController.h
//  TableSample2
//
//  Created by Toru Inoue on 11/04/02.
//  Copyright 2011 KISSAKI. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyTableViewCell.h"

@interface TableSample2ViewController : UITableViewController {
	IBOutlet MyTableViewCell * m_cell;
}

@end
