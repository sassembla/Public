//
//  AViewController.h
//  NotificationProject
//
//  Created by Toru Inoue on 11/04/23.
//  Copyright 2011 KISSAKI. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AViewController : UIViewController {
}
- (id) initWithNotification;

- (IBAction) tapped;


@end
