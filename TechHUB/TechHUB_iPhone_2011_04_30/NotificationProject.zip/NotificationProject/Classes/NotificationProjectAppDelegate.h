//
//  NotificationProjectAppDelegate.h
//  NotificationProject
//
//  Created by Toru Inoue on 11/04/23.
//  Copyright 2011 KISSAKI. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AViewController.h"
#import "BViewController.h"


@interface NotificationProjectAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
	
	AViewController * aVCont;
	BViewController * bVCont;
}

- (void) aTappedReaction:(NSNotification * )notif;
- (void) bTappedReaction:(NSNotification * )notif;


@property (nonatomic, retain) IBOutlet UIWindow *window;

@end

