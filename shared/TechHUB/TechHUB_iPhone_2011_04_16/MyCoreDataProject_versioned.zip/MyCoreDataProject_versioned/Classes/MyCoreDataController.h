//
//  MyCoreDataController.h
//  MyCoreDataProject
//
//  Created by Toru Inoue on 11/04/14.
//  Copyright 2011 KISSAKI. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>


@interface MyCoreDataController : NSObject {
	NSManagedObjectContext * myNSManagedObjectContext;
	NSManagedObjectModel * myNSManagedObjectModel;
	NSPersistentStoreCoordinator * myNSPersistentStoreCoordinator;
}

- (void) create;
- (void) load;
- (NSMutableArray * ) loadAsArrayOfMyEntity01;
- (void) deleteFirstObject;
- (void) deleteAllObjects;
- (void) show;

- (NSPersistentStoreCoordinator * ) myNSPersistentStoreCoordinator;
- (NSString * ) applicationDocumentsDirectory;
- (NSManagedObjectModel * ) myNSManagedObjectModel;
- (NSManagedObjectContext * ) myNSManagedObjectContext;
@end
