//
//  MyCoreDataProjectAppDelegate.h
//  MyCoreDataProject
//
//  Created by Toru Inoue on 11/04/14.
//  Copyright 2011 KISSAKI. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyCoreDataProjectAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end

