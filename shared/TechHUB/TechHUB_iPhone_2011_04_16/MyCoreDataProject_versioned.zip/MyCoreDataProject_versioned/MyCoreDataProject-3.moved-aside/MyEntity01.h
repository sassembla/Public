//
//  MyEntity01.h
//  MyCoreDataProject
//
//  Created by Toru Inoue on 11/04/15.
//  Copyright 2011 KISSAKI. All rights reserved.
//

#import <CoreData/CoreData.h>


@interface MyEntity01 :  NSManagedObject  
{
}

@property (nonatomic, retain) NSString * EventName;
@property (nonatomic, retain) NSDate * EventDate;
@property (nonatomic, retain) NSString * EventPlace;

@end



